 
 $con = mysql_connect('localhost','root','Prome89$');
 $mysql_db_name = ('sam', $con)	