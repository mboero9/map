<ul>
  <li>
    <a href="home.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Home</span>
    </a>
  </li>

 <!-- <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Admin de usuarios</span>
    </a>
    <ul class="nav submenu">
      <li><a href="group.php">Administrar Grupos</a> </li>
      <li><a href="users.php">Administrar Usuarios</a> </li>
   </ul>
  </li>
  <li>
    
    <a href="accion.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>Cargar Accion</span>
    </a>
  </li>
  <li>
    <a href="acciones.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Acciones Cerradas</span>
    </a>
	<!--
    <ul class="nav submenu">
       <li><a href="vistaacion.php">Administrar acciones</a> </li>
       <li><a href="accion.php">Agregar acciones</a> </li>
   </ul>
  </li>
 <!-- <li>
    <a href="media.php" >
      <i class="glyphicon glyphicon-picture"></i>
      <span>Medios</span>
    </a>
  </li>
  
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-list"></i>
       <span>Acciones con Movimientos</span>
      </a>
      <ul class="nav submenu">
         <li><a href="sales.php">Administrar Movimientos</a> </li>
         <li><a href="add_sale.php">Agregar movimientos</a> </li>
     </ul>
  </li>
  -->
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-signal"></i>
       <span>Reportes</span>
      </a>
      <ul class="nav submenu">
        <li><a href="daily_sales.php">Fechas </a></li>
        <li><a href="#">Por semana</a></li>
        <li><a href="#">Por Area</a> </li>
      </ul>
  </li>
</ul>