<p>
    <a class="alert twelve button" href="<?php echo CHtml::normalizeUrl(array('upgrade/run')) ?>">
        I've done a backup  of my database. So let's upgrade!
    </a>
</p>

