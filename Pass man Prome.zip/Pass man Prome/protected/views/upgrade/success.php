<h5>Congratulations!</h5>

<p>Upgrade to version <?php echo $version ?> is complete... </p>