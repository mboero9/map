<?php $this->beginContent('application.views.layouts.master'); ?>

    <div class="row">
        <div class="five columns centered" id="login">
            <div class="row">
                <div class="ten columns centered">
                    <?php echo $content; ?>
                </div>
            </div>
        </div>
    </div>

<?php $this->endContent(); ?>