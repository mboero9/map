<?php $this->beginContent('application.views.layouts.master'); ?>

    <div class="container">
        <?php echo $content; ?>
    </div>

<?php $this->endContent(); ?>