<?php $this->beginContent('application.views.layouts.master'); ?>

    <div class="rows">
        <div class="five columns centered panel" id="upgrade">
            <?php echo $content; ?>
        </div>
    </div>

<?php $this->endContent(); ?>