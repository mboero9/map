<?php $this->beginContent('application.views.layouts.main'); ?>

<div id="content">
    <?php echo $content; ?>
</div>

<?php $this->endContent(); ?>