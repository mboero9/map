<?php


/**
 * @property SecurityManager $securityManager
 * @property WebUser $user;
 * @property SettingsComponent $settings
 */
class WebApplication extends CWebApplication
{

}
