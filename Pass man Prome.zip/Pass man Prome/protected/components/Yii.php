<?php


class Yii extends YiiBase
{

    /**
     * @return WebApplication
     */
    public static function app()
    {
        return self::app();
    }
}
