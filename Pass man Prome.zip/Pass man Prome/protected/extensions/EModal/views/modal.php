<?php /* @var EModal $this */ ?>
<?php /* @var string $content */ ?>

<div id="<?php echo $this->id ?>" class="reveal-modal <?php echo $this->type ?>">
    <?php echo $content ?>
    <a class="close-reveal-modal">&#215;</a>
</div>