<?php

return array (
  'db' => 
  array (
    'server' => '127.0.0.1',
    'username' => 'mboero',
    'password' => 'Vitalogy9',
    'name' => 'ppma',
    'port' => '3306',
  ),
  'isInstalled' => true,
  'version' => '0.6.0',
);