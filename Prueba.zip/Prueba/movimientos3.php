<html>
<head>


  <title>Carga de Movimiento</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
    
</head>
<body>


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Nuevo Movimiento</a>
    </div>
    <button class="btn btn-danger navbar-btn" onclick="location.href='principal.php'">Volver</button> 
  </div>
</nav>


	<div class="container">
		
	<form action="procesomov.php" method="post">
    <div class="form-group">
     
<!--	 <label for="accion">Accion:</label>
      <input type="accion" class="form-control" id="accion" placeholder="Ingresa accion">
	  
    </div> -->

	
<?php
$db_host = 'localhost'; // Server Name
$db_user = 'root'; // Username
$db_pass = 'Micro2017'; // Password
$db_name = 'sam'; // Database Name

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}
$id = $_GET['id'];
//$sql = "SELECT * FROM accionesdemejora where id = '$id'";
$sql = "SELECT * FROM accionesdemejora WHERE id='$id'";

$sql2 =	"UPDATE titulo FROM accionesdemejora WHERE id='$id'";	

$query = mysqli_query($conn, $sql);


if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}


?>
	

	
		<script>
		function habilitar(value)
		{
			if(value=="Derivacion" || value==true)
			{
				// habilitamos
				document.getElementById("Derivad_a").disabled=false;
			}else if(value=="2" || value==false){
				// deshabilitamos
				document.getElementById("Derivado_a").disabled=true;
			}
		}
	</script>
		

	<?php

		if ($row = mysqli_fetch_array($query))
		{
			echo '<tr>
					<td><div class="form-group"><label for="id">Accion:'.$row['id'].'</div></td>
					<td> <div class="form-group">
 <label for="derivado_a">Derivado a:</label	<input type="text" class="form-control" name="derivado_a" placeholder="Ingresa derivacion"> </div> </td>
<td>
<div class="form-group">
			<label for="plazo">Plazo:</label>
			<input type="date">
	</div></td>
				</tr>';

		}?>
	
</form>
	
</body> 
</html>