 
 $con = mysql_connect('localhost','root','Prome2017');
 $mysql_db_name = ('sam', $con)	