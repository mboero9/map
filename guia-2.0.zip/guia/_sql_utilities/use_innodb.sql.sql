
ALTER TABLE addressbook       ENGINE = InnoDB;
ALTER TABLE group_list        ENGINE = InnoDB;
ALTER TABLE address_in_groups ENGINE = InnoDB;
