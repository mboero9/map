ALTER TABLE `group_list` add column `group_parent_id` int(9) default NULL after group_id;
