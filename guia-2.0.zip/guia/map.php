<!DOCTYPE html>
<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
  <title>Google Maps Multiple Markers</title> 
  <script src="http://maps.google.com/maps/api/js?sensor=false" 
          type="text/javascript"></script>
</head> 
<body>
  <div id="map" style="width: 90%; height: 600px;"></div>

<?

	include( "/u01/conexion.php" );
	$user = $CON_usuario;
	$passwd = $CON_pass;
	$db = 'padron';
	$port = 5432;
	$host = '172.17.12.196';
	$strCnx = "host=$host port=$port dbname=$db user=$user password=$passwd";
	$connection = pg_connect($strCnx) or die ("Error de conexion. ". pg_last_error());
	
	if ( $_GET['nFilial'] )
	{
		$nFilial = $_GET['nFilial'];
		
		$nCantidad = 0;
		
		if ( $nFilial != 'Todos' )
		{
			$nSql = "select count(*) as cant
						from padron car
						inner join cliente cli
						on car.nrodoccliente = cli.docclte
						inner join cpageoref geo
						on cli.cpa = geo.cpa
						where filial = '".$nFilial."'
						and estado = 'Vigente'
						and cpaok = 1;";
		}
		else
		{
			$nSql = "select count(*) as cant
						from padron car
						inner join cliente cli
						on car.nrodoccliente = cli.docclte
						inner join cpageoref geo
						on cli.cpa = geo.cpa
						where estado = 'Vigente'
						and cpaok = 1;";
		}
		
						
		$result = pg_query($nSql);
		
		
		//echo "<br>".$nSql;		
		
		if ($line = pg_fetch_row($result))
		{
			$nCantidad = $line[0];
		}
		
		$nCantidadSinLatitud = 0;
		
		if ( $nFilial != 'Todos' )
		{
			$nSql = "select count(*) as cant
						from padron car
						inner join cliente cli
						on car.nrodoccliente = cli.docclte
						inner join cpageoref geo
						on cli.cpa = geo.cpa
						where filial = '".$nFilial."'
						and estado = 'Vigente'
						and lat = '0'
						and cpaok = 1;";
		}
		else
		{
			$nSql = "select count(*) as cant
						from padron car
						inner join cliente cli
						on car.nrodoccliente = cli.docclte
						inner join cpageoref geo
						on cli.cpa = geo.cpa
						where estado = 'Vigente'
						and lat = '0'
						and cpaok = 1;";

		}
						
		$result = pg_query($nSql);
		
		
		//echo "<br>".$nSql;		
		
		if ($line = pg_fetch_row($result))
		{
			$nCantidadSinLatitud = $line[0];
		}
		
		$nCantidadSinCliente = 0;
		
		if ( $nFilial != 'Todos' )
		{
			$nSql = "select count(*) as cant
						from padron car
						where filial = '".$nFilial."'
						and estado = 'Vigente';";
		}
		else
		{
			$nSql = "select count(*) as cant
						from padron car
						where estado = 'Vigente';";
		}
		
						
		$result = pg_query($nSql);
		
		
		//echo "<br>".$nSql;		

		
		if ($line = pg_fetch_row($result))
		{
			$nCantidadSinCliente = $line[0];
		}
		
		if ( $nFilial != 'Todos' )
		{
			$nSql = "select distinct SUBSTRING( pa.domicilio, length(pa.domicilio) - 7,length(pa.domicilio)), car.zona, pa.filial, replace( pa.nombrecliente, '#', 'ñ' ) as nombrecliente, pa.nrodoccliente, lat, lon, bi.diasatr as dias, bi.deudaexigible as deuda
				from cartera car
				inner join padron pa
				on car.solicitud = pa.idsolicitud
				left join bitacora bi
				on car.solicitud = bi.solicitud
				inner join cpageoref geo
				on SUBSTRING( pa.domicilio, length(pa.domicilio) - 7,length(pa.domicilio)) = geo.cpa
				where pa.filial = '".$nFilial."'
				and estado = 'Vigente'
				and producto = '330';";
		}
		else
		{
			$nSql = "select distinct SUBSTRING( pa.domicilio, length(pa.domicilio) - 7,length(pa.domicilio)), car.zona, pa.filial, replace( pa.nombrecliente, '#', 'ñ' ) as nombrecliente, pa.nrodoccliente, lat, lon, bi.diasatr as dias, bi.deudaexigible as deuda
				from cartera car
				inner join padron pa
				on car.solicitud = pa.idsolicitud
				left join bitacora bi
				on car.solicitud = bi.solicitud
				inner join cpageoref geo
				on SUBSTRING( pa.domicilio, length(pa.domicilio) - 7,length(pa.domicilio)) = geo.cpa
				where estado = 'Vigente'
				and producto = '330'
				order by car.zona;";
		}				
						
		$result = pg_query($nSql);
		
		$arrayColorMark = array("http://google.com/mapfiles/ms/micons/red-dot.png");
		array_push($arrayColorMark, "http://google.com/mapfiles/ms/micons/orange-dot.png" );
		array_push($arrayColorMark, "http://google.com/mapfiles/ms/micons/yellow-dot.png" );
		array_push($arrayColorMark, "http://google.com/mapfiles/ms/micons/red-dot.png" );
		array_push($arrayColorMark, "http://google.com/mapfiles/ms/micons/green-dot.png" );
		array_push($arrayColorMark, "http://google.com/mapfiles/ms/micons/green-dot.png" );
		array_push($arrayColorMark, "http://google.com/mapfiles/ms/micons/ltblue-dot.png" );
		array_push($arrayColorMark, "http://google.com/mapfiles/ms/micons/blue-dot.png" );

		//echo "<br>".$nSql;
		
		$nContador = 0;
		
		$LatPrinc = -34.599937;
		$LonPrinc = -58.417665;
		
		while ($line = pg_fetch_row($result))
		{
				//echo "<br>".$line[1];
			//echo "<br>".$line[7];
			if ( $line[6] <> '0')
			{
				$nContador++;
				
				if ( $nContador == 1 )
				{
					$LatPrinc = $line[5];
					$LonPrinc = $line[6];
				}
				$lat = $line[5];
				$lng = $line[6];
				
				$sNombre = str_replace( "'", "", $line[3] );
				
				$Nombre = "Nombre: ".str_replace( ',', ', ', $sNombre )."<br>DNI: ".$line[4]."<br>Sucursal: ".$line[2].($line[7]?("<br>Moroso: SI"):"").($line[7]?("<br>D&iacute;as de atraso: ".$line[7]):"").($line[7]?("<br>Deuda: $".str_replace( '.', ',', $line[8] )):"");
				//$Nombre = "Nombre: ".$line[3]."<br>DNI: ".$line[4]."<br>Sucursal: ".$line[2].($line[7]?("<br>Moroso: SI"):"");
				//echo "<br>".$lat."--".$lng;
				if ( $nContador > 1 )
				{
					$sLocation .= ",";
				}
				
				if ( $nFilial != 'Todos' )
				{
					$sLocation .= "['".$Nombre."', ".$line[5].", ".$line[6].", ".$nContador.", ".($line[7]!=''?("'images/red-dot.png'"):"'images/green-dot.png'")."]";
				}
				else
				{
					$nColorMark = "";
					
					if ( $line[1] == "INTERIOR Sur" )
					{
						$nColorMark = "images/ltblue-dot.png";
					}
					else if ( $line[1] == "NORTE" )
					{
						$nColorMark = "images/orange-dot.png";
					}
					else if ( $line[1] == "INTERIOR" )
					{
						$nColorMark = "images/ltblue-dot.png";
					}
					else if ( $line[1] == "OESTE" )
					{
						$nColorMark = "images/yellow-dot.png";
					}
					else if ( $line[1] == "INTERIOR Centro" )
					{
						$nColorMark = "images/blue-dot.png";
					}
					else if ( $line[1] == "SUR" )
					{
						$nColorMark = "images/red-dot.png";
					}
					
					$sLocation .= "['".$Nombre."', ".$line[5].", ".$line[6].", ".$nContador.", '".$nColorMark."']";			
				}
			}
		}
		
		echo $sLocation;	

		echo "<br>Cantidad con Latitud: ".$nCantidad;
		echo "<br>Cantidad sin Latitud: ".$nCantidadSinLatitud;
		echo "<br>Cantidad Total: ".$nCantidadSinCliente;
  

		?>
		
		<script type="text/javascript">
			var locations = [
			  <?
			  echo $sLocation;
			  ?>
			];
			
			

			var map = new google.maps.Map(document.getElementById('map'), {
			  zoom: 10,
			  center: new google.maps.LatLng(<?=$LatPrinc?>, <?=$LonPrinc?>),
			  mapTypeId: google.maps.MapTypeId.ROADMAP
			});
		
			var infowindow = new google.maps.InfoWindow();
		
			var marker, i;
		
			for (i = 0; i < locations.length; i++) {  
			  marker = new google.maps.Marker({
				position: new google.maps.LatLng(locations[i][1], locations[i][2]),
				map: map,
				icon: locations[i][4]


			  });
		
			  google.maps.event.addListener(marker, 'click', (function(marker, i) {
				return function() {
				  infowindow.setContent(locations[i][0]);
				  infowindow.open(map, marker);
				}
			  })(marker, i));
			}
		</script>
		
		<?
						
	}
	else
	{
		echo "Debe ingresar el Nro de filial";
	}
	
	
	if (pg_num_rows($result))
	{
		$lat =pg_result($result, 0,5);
		$lng =pg_result($result, 0,6);
	}
	else
	{
		printf("<br>CPA=%s No encontrado en la Base!!!<br>",$cpa);	
		
//echo isset($_GET['nFilial']) ? $_GET['nFilial'] : '7185';	    
	
	}
/*
"select zona, filial, nombrecliente, nrodoccliente, docclte, nombre, cli.cpa, lat, lon
from cartera car
inner join cliente cli
on car.nrodoccliente = cli.docclte
inner join cpageoref geo
on cli.cpa = geo.cpa
where filial = '7185'
and cpaok = 1
order by nrodoccliente"
*/
?>

 
</body>
</html>


